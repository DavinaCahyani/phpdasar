<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_sekolah";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Koneksi database gagal: " . $conn->connect_error);
}
echo "Koneksi database berhasil";
?>